from pathlib import Path
import json, re, subprocess

ROOT=Path(__file__).resolve().parents[1]
INDEX=ROOT/'index.html'


def extract_function(src,name):
    m=re.search(rf'function\s+{re.escape(name)}\s*\([^)]*\)\s*\{{',src)
    assert m, f'{name} not found'
    start=m.start()
    brace=src.find('{',m.start())
    depth=0
    quote=None
    esc=False
    i=brace
    while i < len(src):
        ch=src[i]
        if quote:
            if esc:
                esc=False
            elif ch=='\\':
                esc=True
            elif ch==quote:
                quote=None
        else:
            if ch in "'\"`":
                quote=ch
            elif ch=='{':
                depth+=1
            elif ch=='}':
                depth-=1
                if depth==0:
                    return src[start:i+1]
        i+=1
    raise AssertionError(f'unclosed function {name}')


def run_cases():
    src=INDEX.read_text(encoding='utf-8')
    fn=extract_function(src,'studyCtaState')
    script=f"""
    let progress={{topics:{{}},learningPath:{{completed:{{}}}},highlights:{{}},readingPositions:{{}},currentStudy:null}};
    function slug(s=''){{return String(s).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');}}
    function readerKey(disc,id){{return `${{slug(disc)}}::${{id}}`;}}
    function readingPositionFor(disc,id){{return progress?.readingPositions?.[readerKey(disc,id)]||null;}}
    {fn}
    const item={{discipline:'Direito Penal',id:'penal-tempo',title:'Tempo do Crime'}};
    const out=[];
    out.push(studyCtaState(item));
    progress.currentStudy={{discipline:'Direito Penal',topicId:'penal-tempo',lastAt:Date.now()}};
    out.push(studyCtaState(item));
    progress.topics['penal-tempo']={{studySec:12}};
    out.push(studyCtaState(item));
    progress.topics['penal-tempo']={{studySec:12,completedAt:Date.now()}};
    out.push(studyCtaState(item));
    progress.topics['penal-tempo']={{studySec:0}};
    progress.learningPath.completed['Direito Penal|penal-tempo|__chapter__']={{at:1}};
    out.push(studyCtaState(item));
    console.log(JSON.stringify(out));
    """
    p=subprocess.run(['node','-e',script],cwd=ROOT,text=True,capture_output=True)
    assert p.returncode==0,p.stderr
    return json.loads(p.stdout)


def test_study_cta_depends_on_real_progress_not_current_pointer():
    states=run_cases()
    assert states[0]['label']=='Começar estudo'
    assert states[0]['started'] is False
    # Merely having currentStudy must not imply that study really started.
    assert states[1]['label']=='Começar estudo'
    assert states[1]['started'] is False
    assert states[2]['label']=='Continuar estudo'
    assert states[2]['started'] is True
    assert states[3]['label']=='Revisar conteúdo'
    assert states[3]['completed'] is True
    assert states[4]['label']=='Revisar conteúdo'
    assert states[4]['completed'] is True


def test_home_and_study_screen_use_stateful_cta():
    src=INDEX.read_text(encoding='utf-8')
    render_home=extract_function(src,'renderHome')
    render_study=extract_function(src,'renderStudy')
    assert 'studyCtaState(next)' in render_home
    assert 'homeStudyState.label' in render_home
    assert 'studyCtaState(current' in render_study
    assert 'currentState.started' in render_study
