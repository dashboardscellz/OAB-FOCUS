# OAB Focus v36.1 — CTA de estudo coerente com o progresso

## Problema
O dashboard podia exibir **“Continuar estudo”** mesmo quando o usuário nunca havia estudado a unidade. A causa era `currentOrRecommended()`: quando não havia estudo atual, ele devolvia uma recomendação nova, mas o `renderHome()` tratava qualquer retorno como continuação. Além disso, a trilha v27 considerava `progress.currentStudy` suficiente para classificar uma unidade como iniciada, embora esse ponteiro seja salvo assim que o leitor abre.

## Correção
- Unidade sem progresso real: **Começar estudo**.
- Unidade com tempo/grifo/posição de leitura real: **Continuar estudo**.
- Unidade concluída: **Revisar conteúdo**.
- Apenas abrir uma unidade ou possuir `progress.currentStudy` não conta mais como estudo iniciado.
- O cartão “De onde parou” na tela Estudar só aparece quando há progresso efetivo.
- A trilha progressiva não muda mais para `in_study` apenas por existir um ponteiro de sessão.

## Critério de progresso real
O estado `started` considera tempo de estudo > 0, grifos, posição de leitura significativa ou conclusão registrada. O ponteiro `currentStudy` isolado não é suficiente.

## Cache
`data/v27-patch.js` foi atualizado para `?v=36.1`.
